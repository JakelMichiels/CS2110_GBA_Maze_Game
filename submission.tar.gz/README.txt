The goal of Maze Game is to reach the tresure chest as fast as possible. the lower your score the better you did. 
use the arrow keys to move the character.
press backspace at any time to go back to the start screen.
press enter on the start screen or on the win screen to play the game. 