/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=42x34 tresureChest images/tresureChest.png 
 * Time-stamp: Saturday 04/10/2021, 03:05:21
 * 
 * Image Information
 * -----------------
 * images/tresureChest.png 42@34
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TRESURECHEST_H
#define TRESURECHEST_H

extern const unsigned short tresureChest[1428];
#define TRESURECHEST_SIZE 2856
#define TRESURECHEST_LENGTH 1428
#define TRESURECHEST_WIDTH 42
#define TRESURECHEST_HEIGHT 34

#endif

