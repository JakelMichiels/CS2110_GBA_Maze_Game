/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 maze images/maze.jpg 
 * Time-stamp: Saturday 04/10/2021, 02:55:29
 * 
 * Image Information
 * -----------------
 * images/maze.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MAZE_H
#define MAZE_H

extern const unsigned short maze[38400];
#define MAZE_SIZE 76800
#define MAZE_LENGTH 38400
#define MAZE_WIDTH 240
#define MAZE_HEIGHT 160

#endif

